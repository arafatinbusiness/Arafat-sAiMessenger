package np.com.bimalkafle.easybot

data class MessageModel(
    val message : String,
    val role : String,
)
