package np.com.bimalkafle.easybot

object Constants {

    val apiKey = "AIzaSyDvE45wUlhlsvW_wIyFr9aQNEj3ny3oRH4"
}